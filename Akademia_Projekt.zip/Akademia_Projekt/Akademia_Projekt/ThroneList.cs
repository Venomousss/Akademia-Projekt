﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Akademia_Projekt
{
    //Każda gra rozpoczyna się od takiego składu kart tronów
    public class ThroneList
    {
        public List<Throne> Thrones;

        public ThroneList()
        {
            this.Thrones = new List<Throne>();
            this.Thrones.Add(new Throne() { Points = -1, Swords = 3 });
            this.Thrones.Add(new Throne() { Points = -1, Swords = 1 });
            this.Thrones.Add(new Throne() { Points = -3, Swords = 7 });
            this.Thrones.Add(new Throne() { Points = -1, Swords = 4 });
            this.Thrones.Add(new Throne() { Points = -1, Swords = 2 });
            this.Thrones.Add(new Throne() { Points = -2, Swords = 5 });
            this.Thrones.Add(new Throne() { Points = -2, Swords = 6 });
        }
    }
}
