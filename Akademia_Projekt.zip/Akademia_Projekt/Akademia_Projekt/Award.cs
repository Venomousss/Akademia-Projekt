﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Akademia_Projekt
{
    //zastosowanie polimorfizmu i dziedziczenia
    //Nagroda - trony/żetony, które otrzymują gracze po zakończeniu rundy
    public abstract class Award
    {
        public virtual int Points { get; set; }
        public abstract void GiveToPlayer(Player player);
    }

    public class Throne: Award
    {
        public override int Points { get; set; }
        public int Swords { get; set; }

        public override void GiveToPlayer(Player player)
        {
            player.ThronePoints = player.ThronePoints + this.Points;
            player.Swords = player.Swords + this.Swords;
        }
    }

    public class Token: Award
    {
        public override int Points { get; set; }

        public override void GiveToPlayer(Player player)
        {
            player.PenaltyPoints = player.PenaltyPoints + this.Points;
        }
    }
}
