﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Akademia_Projekt
{
    //ButtonOnTable - przycisk na planszy, pokazujący możliwość położenia nowej karty
    public class ButtonOnTable
    {
        public Button button;
        public double x { get; set; }
        public double y { get; set; }
        public int row { get; set; }
        public double xMargin { get; set; }
        public double yMargin { get; set; }
    }
}
