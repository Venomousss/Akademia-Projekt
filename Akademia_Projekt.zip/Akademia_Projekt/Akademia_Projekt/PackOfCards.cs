﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Akademia_Projekt
{
    //Talia Kart - każda runda rozpoczyna się od tej samej liczby i typów kart
    public class PackOfCards
    {
        public List<Card> Deck;

        public PackOfCards()
        {
            this.Deck = new List<Card>();

            for (int i = 0; i < 9; i++)
                this.Deck.Add(new Card() { House = Card.Color.Red });

            for (int i = 0; i < 9; i++)
                this.Deck.Add(new Card() { House = Card.Color.Black });

            for (int i = 0; i < 9; i++)
                this.Deck.Add(new Card() { House = Card.Color.Yellow });

            for (int i = 0; i < 9; i++)
                this.Deck.Add(new Card() { House = Card.Color.Grey });

        }
    }
}
