﻿//DAWID IDCZAK, GR. ZAAWANSOWANA, 18:30
//INFORMACJE O PROJEKCIE W PLIKU "Informacje.txt"

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Akademia_Projekt
{
    public partial class MainWindow : Window
    {
        Grid newGrid;
        Grid infoGrid;
        List<Card> mojeKarty;
        List<Button> buttonCards;
        List<Image> imageCards;
        List<ButtonOnTable> tableCards;
        List<TextBlock> textPlayers;
        List<TextBlock> textPoints;
        List<TextBlock> textThrones;
        List<Player> players;

        ThroneList thrones;

        TextBlock textBlockInfo;

        int choosedCard = -1;
        int howManyFirstRow = 0;
        int maxInFirstRow = 0;
        int highestRow = 0;
        int howManyPlayers;
        int lastPlayer;
        int currentPlayer;
        int round;

        Vertex[,] board;

        public MainWindow()
        {
            InitializeComponent();
        }

        //wylosuj kartę dla gracza
        private void GetCard(int gracz, ref PackOfCards Cards, Random rand)
        {
            try
            {
                int got = rand.Next(Cards.Deck.Count);
                players[gracz].PlayerCards.Add(Cards.Deck[got]);
                Cards.Deck.RemoveAt(got);
            }
            catch (Exception) { }
        }

        //utwórz listę graczy
        private void CreatePlayers()
        {
            for(int i=0; i<howManyPlayers; i++)
            {
                Player player = new Player();

                if (i == 0)
                    player.Bot = false; //pierwszy gracz to użytkownik
                else
                    player.Bot = true;

                players.Add(player);
            }
        }

        //obsługa kliknięcia przycisku "START"
        private void buttonStart_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (int.Parse(textbox_gracze.Text) > 1 && int.Parse(textbox_gracze.Text) < 7)
                {
                    buttonStart.IsEnabled = false;
                    textbox_gracze.IsEnabled = false;
                    buttonEnd.IsEnabled = true;

                    players = new List<Player> { };
                    howManyPlayers = int.Parse(textbox_gracze.Text);
                    CreatePlayers();
                    mojeKarty = new List<Card> { };

                    int ileRozdac = HowManyCardsForPlayers();
                    maxInFirstRow = MaxAmountOfCardsInFirstRow();
                    thrones = new ThroneList();

                    //w celu utworzenia tabeli z aktualnymi wynikami
                    textPlayers = new List<TextBlock> { };
                    textPoints = new List<TextBlock> { };
                    textThrones = new List<TextBlock> { };

                    //utworzenie tabeli z wynikami
                    CreateInfoGrid();
                    PrepareInfoText();
                    FillInfoGrid();

                    //utworzenie textblocku na informację o numerze aktualnej rundy
                    textBlockInfo = new TextBlock();
                    textBlockInfo.Height = 30;
                    textBlockInfo.Width = 200;
                    textBlockInfo.Text = "RUNDA 1";
                    textBlockInfo.FontSize = 24;
                    textBlockInfo.Foreground = new SolidColorBrush(Colors.Yellow);
                    textBlockInfo.FontWeight = FontWeights.Bold;
                    textBlockInfo.HorizontalAlignment = HorizontalAlignment.Right;
                    textBlockInfo.VerticalAlignment = VerticalAlignment.Bottom;
                    Thickness margin = textBlockInfo.Margin;
                    margin.Top = 5;
                    textBlockInfo.Margin = margin;
                    spInfo.Children.Add(textBlockInfo);

                    int round = 0; //początek gry - pierwsza runda
                    currentPlayer = round; //oznaczenie gracza, aktualnie wykonującego ruch

                    StartNewRound(ileRozdac); //rozpoczęcie nowej rundy
                }
                else
                {
                    MessageBox.Show("Niepoprawna liczba!", "Wartość niepoprawna");
                }
            }
            catch(FormatException)
            {
                MessageBox.Show("Błąd we wprowadzonej liczbie!", "Błąd!");
            }
            
        }

        //rozpoczęcie nowej rundy
        private void StartNewRound(int ileRozdac)
        {
            textBlockInfo.Text = "Runda " + (round+1).ToString();
            howManyFirstRow = 0;

            currentPlayer = round; //zaczyna gracz o numerze rozpoczętej rundy

            board = new Vertex[15, 15];

            //utworzenie nowej talii kart
            PackOfCards Cards = new PackOfCards();
            Random rand = new Random();
            for (int i = 0; i < howManyPlayers; i++) //rozdaj wszystkim graczom
                for (int j = 0; j < ileRozdac; j++)
                {
                    GetCard(i, ref Cards, rand);
                }

            //ile kart ma aktualnie gracz w ręce
            foreach (Player player in players)
            {
                player.HowManyCards = ileRozdac;
            }

            //utwórz tabelę na karty i przyciski wyboru karty
            CreateCollectionGrid(ileRozdac);
            buttonCards = new List<Button> { };
            imageCards = new List<Image> { };
            PrepareCollectionImagesAndButtons();
            FillCollectionGrid(ileRozdac);
            placeFirstButton();

            if (currentPlayer != 0)
            {
                //zablokuj przyciski na czas ruchu gracza komputerowego
                foreach (Button button in buttonCards)
                {
                    button.IsEnabled = false;
                }

                foreach (ButtonOnTable tabButton in tableCards)
                {
                    tabButton.button.IsEnabled = false;
                }
                
                //zmniejsz tymczasowo currentPlayer
                currentPlayer--;

                //wykonaj ruch bota
                BotsTurn();
            }
        }

        //ile kart rozdać - zależy od liczby graczy
        private int HowManyCardsForPlayers()
        {
            if (howManyPlayers == 2)
            {
                return 14;
            }
            else if (howManyPlayers == 3)
            {
                return 12;
            }
            else if (howManyPlayers == 4)
            {
                return 9;
            }
            else if (howManyPlayers == 5)
            {
                return 7;
            }
            else
            {
                return 6;
            }
        }

        //maksymalna liczba kart w pierwszym rzędzie
        private int MaxAmountOfCardsInFirstRow()
        {
            if (howManyPlayers == 2)
            {
                return 7;
            }
            else
            {
                return 8;
            }
        }

        private void CreateInfoGrid()
        {
            infoGrid = new Grid();
            infoGrid.HorizontalAlignment = HorizontalAlignment.Right;
            infoGrid.VerticalAlignment = VerticalAlignment.Top;

            ColumnDefinition gridCol1 = new ColumnDefinition();
            ColumnDefinition gridCol2 = new ColumnDefinition();
            ColumnDefinition gridCol3 = new ColumnDefinition();
            infoGrid.ColumnDefinitions.Add(gridCol1);
            infoGrid.ColumnDefinitions.Add(gridCol2);
            infoGrid.ColumnDefinitions.Add(gridCol3);

            List<RowDefinition> rowDefs = new List<RowDefinition> { };

            //lista definicji wierszy w gridzie (czy to potrzebne?)
            for (int i = 0; i < howManyPlayers+1; i++)
            {
                RowDefinition gridRow = new RowDefinition();
                gridRow.Height = GridLength.Auto;
                gridRow.Tag = i;
                infoGrid.RowDefinitions.Add(gridRow);
                rowDefs.Add(gridRow);
            }
        }

        private void PrepareInfoText()
        {
            //wypełnij nagłówki (GRACZ)
            TextBlock headerPlayer = new TextBlock();
            headerPlayer.Height = 20;
            headerPlayer.Width = 100;
            headerPlayer.Text = "GRACZ";
            headerPlayer.Foreground = new SolidColorBrush(Colors.Red);
            headerPlayer.FontWeight = FontWeights.Bold;
            headerPlayer.HorizontalAlignment = HorizontalAlignment.Center;
            headerPlayer.VerticalAlignment = VerticalAlignment.Center;

            Grid.SetRow(headerPlayer, 0);
            Grid.SetColumn(headerPlayer, 0);
            textPlayers.Add(headerPlayer);

            //wypełnij nagłówki (PUNKTY)
            TextBlock headerPoint = new TextBlock();
            headerPoint.Height = 20;
            headerPoint.Width = 100;
            headerPoint.Text = "PUNKTY KARNE";
            headerPoint.Foreground = new SolidColorBrush(Colors.Red);
            headerPoint.FontWeight = FontWeights.Bold;
            headerPoint.HorizontalAlignment = HorizontalAlignment.Center;
            headerPoint.VerticalAlignment = VerticalAlignment.Center;

            Grid.SetRow(headerPoint, 0);
            Grid.SetColumn(headerPoint, 1);
            textPoints.Add(headerPoint);

            //wypełnij nagłówki (TRONY)
            TextBlock headerThrone = new TextBlock();
            headerThrone.Height = 20;
            headerThrone.Width = 100;
            headerThrone.Text = "TRONY";
            headerThrone.Foreground = new SolidColorBrush(Colors.Red);
            headerThrone.FontWeight = FontWeights.Bold;
            headerThrone.HorizontalAlignment = HorizontalAlignment.Center;
            headerThrone.VerticalAlignment = VerticalAlignment.Center;

            Grid.SetRow(headerThrone, 0);
            Grid.SetColumn(headerThrone, 2);
            textThrones.Add(headerThrone);

            for(int i=0; i<howManyPlayers; i++)
            {
                //dodaj info o graczach
                TextBlock textPlayer = new TextBlock();
                textPlayer.Height = 20;
                textPlayer.Width = 100;

                if(i==0)
                    textPlayer.Text = "TY";
                else
                    textPlayer.Text = "BOT " + i.ToString();

                textPlayer.HorizontalAlignment = HorizontalAlignment.Center;
                textPlayer.VerticalAlignment = VerticalAlignment.Center;
                textPlayer.Foreground = new SolidColorBrush(Colors.Red);

                Grid.SetRow(textPlayer, i+1);
                Grid.SetColumn(textPlayer, 0);
                textPlayers.Add(textPlayer);

                //dodaj info o punktach
                TextBlock textPoint = new TextBlock();
                textPoint.Height = 20;
                textPoint.Width = 100;
                textPoint.Text = "0";
                textPoint.HorizontalAlignment = HorizontalAlignment.Center;
                textPoint.VerticalAlignment = VerticalAlignment.Center;
                textPoint.Foreground = new SolidColorBrush(Colors.Red);

                Grid.SetRow(textPoint, i+1);
                Grid.SetColumn(textPoint, 1);
                textPoints.Add(textPoint);

                //dodaj info o tronach
                TextBlock textThrone = new TextBlock();
                textThrone.Height = 20;
                textThrone.Width = 100;
                textThrone.Text = "0";
                textThrone.HorizontalAlignment = HorizontalAlignment.Center;
                textThrone.VerticalAlignment = VerticalAlignment.Center;
                textThrone.Foreground = new SolidColorBrush(Colors.Red);

                Grid.SetRow(textThrone, i+1);
                Grid.SetColumn(textThrone, 2);
                textThrones.Add(textThrone);
            }
        }

        private void FillInfoGrid()
        {
            for (int i = 0; i < howManyPlayers+1; i++)
            {
                infoGrid.Children.Add(textPlayers[i]);
                infoGrid.Children.Add(textPoints[i]);
                infoGrid.Children.Add(textThrones[i]);
            }

            spInfo.Children.Add(infoGrid);
        }

        private void CreateCollectionGrid(int ileRozdac)
        {
            newGrid = new Grid();
            newGrid.HorizontalAlignment = HorizontalAlignment.Left;
            newGrid.VerticalAlignment = VerticalAlignment.Top;

            Thickness margin = newGrid.Margin;
            margin.Left = 5;
            newGrid.Margin = margin;

            ColumnDefinition gridCol1 = new ColumnDefinition();
            ColumnDefinition gridCol2 = new ColumnDefinition();
            newGrid.ColumnDefinitions.Add(gridCol1);
            newGrid.ColumnDefinitions.Add(gridCol2);
            List<RowDefinition> rowDefs = new List<RowDefinition> { };

            for (int i = 0; i < ileRozdac; i++)
            {
                RowDefinition gridRow = new RowDefinition();
                gridRow.Height = new GridLength(35);
                gridRow.Tag = i;
                newGrid.RowDefinitions.Add(gridRow);
                rowDefs.Add(gridRow);
            }
        }

        private void PrepareCollectionImagesAndButtons()
        {
            string color = "";
            int counter = 0;
            foreach (Card myCard in players[0].PlayerCards)
            {
                if(myCard.House == Card.Color.Red)
                    color = "red.png";    
                else if (myCard.House == Card.Color.Yellow)
                    color = "yellow.png";
                else if (myCard.House == Card.Color.Grey)
                    color = "grey.png";
                else if (myCard.House == Card.Color.Black)
                    color = "black.png";

                Image image = new Image();
                image.Source = new BitmapImage(new Uri(color, UriKind.Relative));
                image.Height = 30;
                image.Width = 30;
                image.Tag = counter;
                image.HorizontalAlignment = HorizontalAlignment.Left;

                Grid.SetRow(image, counter);
                Grid.SetColumn(image, 0);
                imageCards.Add(image);

                Button button = new Button();
                button.Content = "WYBIERZ";
                button.Tag = counter;
                button.Height = 30;
                button.Width = 100;
                Grid.SetRow(button, counter);
                Grid.SetColumn(button, 1);

                button.Click += new RoutedEventHandler(chooseCard);
                buttonCards.Add(button);
                counter++;
            }
        }

        private void FillCollectionGrid(int ileRozdac)
        {
            for (int i = 0; i < ileRozdac; i++)
            {
                newGrid.Children.Add(imageCards[i]);
                newGrid.Children.Add(buttonCards[i]);
            }

            sp_MojeKarty.Children.Add(newGrid);
        }

        //czy można położyć kartę w danym miejscu na planszy
        private bool isCardPermitted(int x, int y, Card.Color color)
        {
            if (y == 0 || board[x, y - 1].color == color || board[x + 1, y - 1].color == color)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        //działania po wybraniu karty
        private void chooseCard(object sender, RoutedEventArgs e)
        {
            Button clicked = (Button)sender;
            choosedCard = Convert.ToInt32(clicked.Tag);

            if (clicked.Content.Equals("WYBIERZ"))
            {
                clicked.Content = "ANULUJ";

                foreach(Button button in buttonCards)
                {
                    if(button.Tag!=clicked.Tag)
                    {
                        button.IsEnabled = false;
                    }
                }

                foreach(ButtonOnTable tabButton in tableCards)
                {
                    tabButton.button.IsEnabled = true;
                }

            }
            else
            {
                clicked.Content = "WYBIERZ";

                foreach (Button button in buttonCards)
                {
                    button.IsEnabled = true;
                }

                foreach (ButtonOnTable tabButton in tableCards)
                {
                    tabButton.button.IsEnabled = false;
                }

            }
        }

        //działania po kliknięciu "KONIEC" - zakończenie udziału w rundzie
        private void buttonEnd_Click(object sender, RoutedEventArgs e)
        {
            players[0].End = true;
            lastPlayer = 0;
            BotsTurn();
        }

        //połóż pierwszy przycisk na planszy - miejsce na pierwszą kartę
        private void placeFirstButton()
        {
            tableCards = new List<ButtonOnTable> { };
            ButtonOnTable first = new ButtonOnTable();
            first.button = new Button();
            first.button.Width = 35;
            first.button.Height = 35;
            first.button.Content = "Połóż";
            first.button.HorizontalAlignment = HorizontalAlignment.Left;
            first.button.IsEnabled = false;

            if(maxInFirstRow==7)
            {
                first.button.Tag = "6,0";
                first.x = 6;
            }
            else
            {
                first.button.Tag = "7,0";
                first.x = 7;
            }

            first.y = 0;
            first.row = 1;
            first.button.Click += new RoutedEventHandler(PutOnTableEvent);

            Thickness margin = first.button.Margin;          
            margin.Top = spTable.Height-50;
            margin.Left = spTable.Width / 2;

            first.button.Margin = margin;

            tableCards.Add(first);

            Vertex next = new Vertex();
            next.xMargin = margin.Left;
            next.yMargin = margin.Top;

            if(maxInFirstRow==7)
            {
                board[6, 0] = next;
            }
            else
            {
                board[7, 0] = next;
            }

            foreach(ButtonOnTable button in tableCards)
            {
                spTable.Children.Add(button.button);
            }
        }

        private void PutOnTableEvent(object sender, RoutedEventArgs e)
        {
            Button clicked = (Button)sender;
            PutOnTable(clicked);
        }

        //położenie na stole karty (zamiana przycisku na obrazek karty)
        private void PutOnTable(Button clicked)
        {
            Card.Color color = players[currentPlayer].PlayerCards[choosedCard].House;
            string[] xy = clicked.Tag.ToString().Split(',');
            int x = int.Parse(xy[0]);
            int y = int.Parse(xy[1]);

            //sprawdź, czy karta w danym kolorze może zostać położona
            if (isCardPermitted(x, y, color) == true)
            {
                if (currentPlayer == 0)
                {
                    newGrid.Children.Remove(imageCards[choosedCard]);
                    newGrid.Children.Remove(buttonCards[choosedCard]);
                }

                if (currentPlayer != 0)
                {
                    players[currentPlayer].PlayerCards.RemoveAt(choosedCard);
                }

                Image image = new Image();
                image.Source = new BitmapImage(new Uri(color + ".png", UriKind.Relative));
                image.Height = 35;
                image.Width = 35;
                image.HorizontalAlignment = HorizontalAlignment.Left;

                string tmp = Convert.ToString(clicked.Tag);

                image.Margin = clicked.Margin;

                spTable.Children.Remove(clicked);
                spTable.Children.Add(image);

                board[int.Parse(xy[0]), int.Parse(xy[1])].isButton = false;
                board[int.Parse(xy[0]), int.Parse(xy[1])].isCard = true;
                board[int.Parse(xy[0]), int.Parse(xy[1])].color = color;

                //jeśli karta została położona w pierwszym rzędzie
                if (int.Parse(xy[1]) == 0)
                {
                    howManyFirstRow++;
                }

                //usuń przyciski "nadprogramowe"
                if (howManyFirstRow == maxInFirstRow)
                {
                    deleteButtons();
                }

                updateTable();
                EnableCards();
                DisableButtons();

                //zmniejszyć info o liczbie kart gracza
                players[currentPlayer].HowManyCards--;
                if(players[currentPlayer].HowManyCards==0)
                {
                    players[currentPlayer].End = true;
                    lastPlayer = currentPlayer;
                }

                //usunąć przycisk z listy
                foreach(ButtonOnTable but in tableCards)
                {
                    if(but.x==x && but.y==y)
                    {
                        tableCards.Remove(but);
                        break;
                    }
                }

                //działania po położeniu karty (określenie, czyj teraz ruch)
                if(currentPlayer == howManyPlayers-1)
                {
                    currentPlayer = 0;
                    //czy gracz już przypadkiem nie zakończył swojej rundy?
                    if (players[0].End == true)
                        BotsTurn();
                }
                else if(currentPlayer>=0)
                {
                    BotsTurn();
                }

                if(players[0].End==true)
                {
                    BotsTurn();
                }
            }
            else
            {
                //jeżeli ruch wykonuje użytkownik
                MessageBox.Show("Karta o tym kolorze nie może zostać położona", "Karta niedozwolona!");
            }
        }

        //działanie botów
        private void BotsTurn()
        {
            currentPlayer++;
            bool located = false;

            try
            {
                if (players[currentPlayer].End == false) //jeśli gracz ciągle bierze udział w rundzie
                {
                    for (int i = 0; i < players[currentPlayer].HowManyCards; i++)
                    {
                        //próba położenia na jakiekolwiek miejsce na planszy
                        foreach (ButtonOnTable button in tableCards)
                        {
                            string[] xy = button.button.Tag.ToString().Split(',');
                            int x = int.Parse(xy[0]);
                            int y = int.Parse(xy[1]);

                            //czy mogę położyć w tym miejscu?
                            if (isCardPermitted(x, y, players[currentPlayer].PlayerCards[i].House))
                            {
                                choosedCard = i;
                                PutOnTable(button.button);
                                located = true;
                                break;
                            }
                        }

                        if (located == true)
                            break;
                    }

                    if (located == false) //bot nie może położyć karty - koniec rundy dla niego
                    {
                        players[currentPlayer].End = true;
                        lastPlayer = currentPlayer;
                    }
                }
            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("The argument is out of range, please specify a valid argument");
            }

            if (IsItTheEnd() == true)
            {
                if(lastPlayer==0)
                {
                    MessageBox.Show("Wygrałeś rundę!", "Koniec rundy");
                }
                else
                {
                    MessageBox.Show("Wygrał bot nr " + lastPlayer, "Koniec rundy");    
                }              

                //wyczyść gridy:
                sp_MojeKarty.Children.Clear();
                spTable.Children.Clear();

                EndOfRound();

                //czy to już była ostatnia runda?
                if(round==howManyPlayers-1)
                {
                    EndOfGame();
                }
                else
                {
                    round++;
                    currentPlayer = round - 1;
                    StartNewRound(HowManyCardsForPlayers());
                }

            }
            else if(currentPlayer==howManyPlayers-1)
            {
                currentPlayer = 0;

                //sprawdź, czy użytkownik może jeszcze grać
                if(players[0].End==true)
                {
                    BotsTurn();
                }
            }
        }

        private bool IsItTheEnd()
        {
            //czy jest to koniec rundy - wszyscy gracze skończyli?
            foreach(Player player in players)
            {
                if (player.End == false)
                    return false;
            }
            return true;
        }

        //koniec gry
        private void EndOfGame()
        {
            string announcement = "Po podliczeniu wszystkich wyników:\n\n"; //podsumowanie na koniec gry
            int winner = -1;
            int mostPoints = 1000;

            List<int> SameResults = new List<int> { };

            for (int i = 0; i < howManyPlayers; i++ )
            {
                if(i==0)
                    announcement += "Ostatecznie zdobyłeś " + (players[0].ThronePoints+players[0].PenaltyPoints).ToString() + " punktów.\n"; 
                else
                    announcement += "Bot " + i.ToString() + " zdobywa " + (players[i].ThronePoints + players[i].PenaltyPoints).ToString() + " punktów.\n"; 

                if((players[i].ThronePoints+players[i].PenaltyPoints)<mostPoints)
                {
                    winner = i;
                    mostPoints = players[i].ThronePoints + players[i].PenaltyPoints;
                }
                else if ((players[i].ThronePoints+players[i].PenaltyPoints)==mostPoints)
                {
                    if(SameResults.Count==0) //jeśli lista graczy z identycznymi wynikami jest pusta - dodaj do listy poprzednika
                    {
                        SameResults.Add(winner);
                    }
                    SameResults.Add(i);
                }
            }

            if(SameResults.Count>0) //są zwycięzcy z taką samą liczbą punktów
            {
                winner = -1;
                int mostSwords = 0;
                foreach(int player in SameResults)
                {
                    if(players[player].Swords>mostSwords)
                    {
                        mostSwords = players[player].Swords;
                        winner = player;
                    }
                }
            }

            announcement += "\n\n(Zwycięża gracz z najmniejszą liczbą punktów. " +
                 "Jeśli liczba punktów między graczami jest równa - decyduje liczba mieczy z kart tronów.)\n\n";
            
            if(winner!=0)
            {
                announcement += "Wygrywa Bot " + winner.ToString() + ".";
            }
            else
            {
                announcement += "WYGRYWASZ!";
            }

            MessageBox.Show(announcement, "KONIEC!");
            Application.Current.Shutdown();
        }

        //koniec pojedynczej rundy
        private void EndOfRound()
        {
            //rozdać trony i punkty
            MessageBox.Show("Dostajesz " + players[0].HowManyCards + " punktów karnych");

            //daj losowy tron zwycięzcy rundy
            Random rand = new Random();
            int got = rand.Next(thrones.Thrones.Count);

            //daj tron graczowi
            thrones.Thrones[got].GiveToPlayer(players[lastPlayer]);
            players[lastPlayer].Thrones++;

            if (lastPlayer == 0)
            {
                MessageBox.Show("Do tego otrzymujesz tron z parametrami:"
                    + thrones.Thrones[got].Points + " punktów oraz "
                        + thrones.Thrones[got].Swords + " mieczy!");
            }

            //usuń tron z listy
            thrones.Thrones.RemoveAt(got);

            //daj punkty wszystkim graczom
            foreach(Player player in players)
            {
                Token token = new Token();
                token.Points = player.HowManyCards;
                token.GiveToPlayer(player);
            }

            //wyczyść karty zawodników i od nowa
            foreach (Player player in players)
            {
                player.PlayerCards.Clear();
                player.End = false;

                //zmień wyniki w Gridzie
                updateResults();
            }

            //usuń przyciski z tableCards
            tableCards.Clear();
        }


        //zaktualizuj tabelę wyników
        private void updateResults()
        {
            for(int i=0; i<howManyPlayers; i++)
            {
                textPoints[i+1].Text = players[i].PenaltyPoints.ToString();
                textThrones[i + 1].Text = players[i].Thrones.ToString();
            }
        }

        private void EnableCards()
        {
            foreach (Button button in buttonCards)
            {
                button.IsEnabled = true;
            }
        }

        private void DisableButtons()
        {
            foreach (ButtonOnTable button in tableCards)
            {
                button.button.IsEnabled = false;
            }
        }

        //dodaj nowe przyciski w zależności od sytuacji na planszy
        private void updateTable()
        {
            int middle;
            if(maxInFirstRow==7)
                middle = 6;
            else
                middle = 7;

            //sprawdź pierwszy rząd (lewa strona)
            if (howManyFirstRow < maxInFirstRow) //jeżeli nie został zapełniony limit kart w pierwszym rzędzie
            {
                for (int i = middle; i > 0; i--)
                {
                    if (board[i, 0] != null && board[i, 0].isCard == true) //jeśli dana karta jest na planszy
                    {
                        if (board[i - 1, 0] == null)
                        {
                            Vertex next = new Vertex();
                            next.isButton = true;
                            double testx = board[i, 0].xMargin;
                            double testy = board[i, 0].yMargin;

                            next.xMargin = board[i, 0].xMargin - 44;
                            next.yMargin = -35;
                            board[i - 1, 0] = next;

                            //dodaj przycisk na planszy
                            addButton(i - 1, 0, board[i, 0].xMargin - 44, -35);
                        }
                    }
                }
            }

            //sprawdź pierwszy rząd (prawa strona)
            if (howManyFirstRow < maxInFirstRow) //jeżeli nie został zapełniony limit kart w pierwszym rzędzie
            {
                for (int i = middle; i < 14; i++)
                {
                    if (board[i, 0] != null && board[i, 0].isCard == true) //jeśli dana karta jest na planszy
                    {
                        if (board[i + 1, 0] == null)
                        {
                            Vertex next = new Vertex();
                            next.isButton = true;
                            double testx = board[i, 0].xMargin;
                            double testy = board[i, 0].yMargin;

                            next.xMargin = board[i, 0].xMargin + 44;
                            next.yMargin = -35;
                            board[i + 1, 0] = next;

                            //dodaj przycisk na planszy
                            addButton(i + 1, 0, board[i, 0].xMargin + 44, -35);
                        }
                    }
                }
            }

            //sprawdź wyższe rzędy
            for (int i = 1; i < highestRow + 1; i++) //aż do najwyższego osiągniętego rzędu
            {
                for (int j = 0; j < ((maxInFirstRow * 2) - 1 - i); j++) //jadę przez cały rząd
                {
                    //najpierw sprawdzam, czy w danym polu jest button/karta. Jeżeli nie - sprawdzam, czy
                    //POWINIEN się tu znaleźć button
                    if(board[j, i]==null) //nic się się znajduje
                    {
                        //i teraz, czy poniżej znajdują się dwie KARTY
                        if(board[j, i-1]!=null && board[j+1, i-1]!=null && board[j, i-1].isCard==true && board[j+1, i-1].isCard==true)
                        {
                            //mogę dodać przycisk powyżej
                            Vertex next = new Vertex();
                            next.isButton = true;

                            next.xMargin = (board[j+1, i-1].xMargin + board[j, i-1].xMargin)/2;
                            if (board[j, i - 1].yMargin == 468)
                            {
                                next.yMargin = -125;
                            }
                            else
                            {
                                next.yMargin = board[j, i - 1].yMargin - 90;
                            }
                            
                            board[j, i] = next;

                            addButton(j, i, next.xMargin, next.yMargin);
                        }
                    }
                }
            }
        }

        //dodaj przycisk (nową możliwość położenia na planszy)
        private void addButton(int x, int y, double xMargin, double yMargin)
        {
            ButtonOnTable next = new ButtonOnTable();
            next.button = new Button();
            next.button.Width = 35;
            next.button.Height = 35;
            
            //zapisz współrzędne elementu tablicy
            next.button.Tag = x.ToString() + "," + y.ToString();
            string disco = x.ToString() + "," + y.ToString();

            next.button.Content = "Połóż";
            next.button.HorizontalAlignment = HorizontalAlignment.Left;
            next.button.IsEnabled = false;

            next.x = x;
            next.y = y;

            next.row = y + 1;

            if(next.row>highestRow)
            {
                highestRow = next.row;
            }

            next.button.Click += new RoutedEventHandler(PutOnTableEvent);

            Thickness margin = next.button.Margin;

            margin.Top = yMargin;

            next.yMargin = margin.Top;
            margin.Left = xMargin;

            next.xMargin = margin.Left;

            next.button.Margin = margin;

            tableCards.Add(next);

            spTable.Children.Add(next.button);
        }

        //usuń "ponadprogramowe" przyciski z pierwszego rzędu
        private void deleteButtons()
        {
            bool removed = false;
            foreach(ButtonOnTable button in tableCards)
            {
                if(button.row==1)
                {
                    spTable.Children.Remove(button.button);
                    tableCards.Remove(button);
                    removed = true;
                    break;
                }
            }
            if(removed==true) //być może jest coś jeszcze do usunięcia - wykonaj jeszcze raz
            {
                deleteButtons();
            }
        }
    }
}
