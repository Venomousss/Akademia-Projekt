﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Akademia_Projekt
{
    //enum
    //Klasa definiująca kartę - jej kolor (przynależność do rodu :P)
    public class Card
    {
        public enum Color
        {
            Red,
            Grey,
            Yellow,
            Black
        };
        public Color House { get; set; }
       
    }
}
