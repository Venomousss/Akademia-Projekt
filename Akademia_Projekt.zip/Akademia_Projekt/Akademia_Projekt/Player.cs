﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Akademia_Projekt
{
    //Gracz i pola, definiujące jego status w grze
    public class Player
    {
        public bool Bot { get; set; }
        public int PenaltyPoints { get; set; }
        public int Thrones { get; set; }
        public int ThronePoints { get; set; }
        public int Swords { get; set; }
        public bool End { get; set; }
        public int HowManyCards { get; set; }
        public List<Card> PlayerCards { get; set; }

        public Player()
        {
            this.PenaltyPoints = 0;
            this.ThronePoints = 0;
            this.Swords = 0;
            this.End = false;
            this.PlayerCards = new List<Card>();
        }
    }
}
