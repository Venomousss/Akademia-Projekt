﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Akademia_Projekt
{
    //"Wierzchołek" - położona karta w grafie (na planszy)
    public class Vertex
    {
        public Card.Color color {get; set;}
        public int Row {get;set;}
        public bool isCard { get; set; }
        public bool isButton { get; set; }
        public double xMargin { get; set; }
        public double yMargin {get;set;}

        public Vertex()
        {
            this.isCard = false;
            this.isButton = false;
        }
    }

}
